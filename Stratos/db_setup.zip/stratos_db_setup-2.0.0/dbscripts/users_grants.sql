use mysql;

INSERT INTO user (User,Host,Password) VALUES('registry','%',PASSWORD('registry'));
INSERT INTO user (User,Host,Password) VALUES('userstore','%',PASSWORD('userstore'));
INSERT INTO user (User,Host,Password) VALUES('billing','%',PASSWORD('billing'));
INSERT INTO user (User,Host,Password) VALUES('bps','%',PASSWORD('bps'));
INSERT INTO user (User,Host,Password) VALUES('hive_user','%',PASSWORD('hive_user'));
INSERT INTO user (User,Host,Password) VALUES('rss_db','%',PASSWORD('rss_db'));
INSERT INTO user (User,Host,Password) VALUES('shopping_cart_db','%',PASSWORD('shopping_cart_db'));

FLUSH PRIVILEGES;

GRANT ALL ON governance.* TO 'registry'@'%';
GRANT ALL ON appserver_config.* TO 'registry'@'%';
GRANT ALL ON bps_config.* TO 'registry'@'%';
GRANT ALL ON brs_config.* TO 'registry'@'%';
GRANT ALL ON bam_config.* TO 'registry'@'%';
GRANT ALL ON cep_config.* TO 'registry'@'%';
GRANT ALL ON dss_config.* TO 'registry'@'%';
GRANT ALL ON esb_config.* TO 'registry'@'%';
GRANT ALL ON gadget_config.* TO 'registry'@'%';
GRANT ALL ON identity_config.* TO 'registry'@'%';
GRANT ALL ON manager_config.* TO 'registry'@'%';
GRANT ALL ON mb_config.* TO 'registry'@'%';
GRANT ALL ON mashup_config.* TO 'registry'@'%';
GRANT ALL ON cg_config.* TO 'registry'@'%';
GRANT ALL ON ts_config.* TO 'registry'@'%';

GRANT ALL ON userstore.* TO 'userstore'@'%';
GRANT ALL ON billing.* TO 'billing'@'%';
GRANT ALL ON bps.* TO 'bps'@'%';
GRANT ALL ON bps_attachment.* TO 'bps'@'%';
GRANT ALL ON bps_ht.* TO 'bps'@'%';
GRANT ALL ON hive_db.* TO 'hive_user'@'%';
GRANT ALL ON rss_db.* TO 'rss_db'@'%'; 
GRANT ALL ON shopping_cart_db.* TO 'shopping_cart_db'@'%';

FLUSH PRIVILEGES;

