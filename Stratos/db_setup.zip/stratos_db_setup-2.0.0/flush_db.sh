#!/bin/bash

SERVER="localhost"
USER="root"
PASSWD="root123"

ECHO=`which echo`
MYSQL=`which mysql`
MYSQL_BASE_CMD="${MYSQL} -u${USER} -p${PASSWD} -h${SERVER}"

# For all DBs

DBS="userstore billing bps rss_db shopping_cart_db appserver_config bps_config brs_config bam_config cep_config dss_config esb_config identity_config manager_config mb_config cg_config ts_config mashup_config governance hive_db"

#DBS="userstore billing bps rss_db shopping_cart_db"
#DBS="appserver_config bps_config brs_config bam_config cep_config dss_config esb_config gadget_config identity_config manager_config mb_config mashup_config governance"

# Creating DBs

for D in ${DBS}; do 
	# Create
	${ECHO} -en "\n Dropping ${D} .. "
	${MYSQL_BASE_CMD} "-e DROP DATABASE IF EXISTS ${D};"
	[ $? == 0 ] && ${ECHO} "[DONE]" || ${ECHO} "[FAILED]"
done

exit $?

