module MCollective
  module Logger
    autoload :Base, "mcollective/logger/base"
  end
end
